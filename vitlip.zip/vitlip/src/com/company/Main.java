package com.company;
import javax.swing.*;
import java.awt.*;

class Board extends JPanel {

    private static final long serialVersionUID = 1L;
    double x[][] = new double[13][4];
    double y[][] = new double[13][4];
    double px;
    double py;

    @Override
    public void paintComponent(Graphics g) {
        super.paintComponent(g);
        setValues();
        drawBeziere(g);
    }

    public void setValues(){
        x[0][0] = 242;
        y[0][0] = 117;
        x[0][1] = 240;
        y[0][1] = 81;
        x[0][2] = 190;
        y[0][2] = 92;
        x[0][3] = 184;
        y[0][3] = 106;

        x[1][0] = 184;
        y[1][0] = 106;
        x[1][1] = 162;
        y[1][1] = 118;
        x[1][2] = 153;
        y[1][2] = 284;
        x[1][3] = 130;
        y[1][3] = 273;

        x[2][0] = 130;
        y[2][0] = 273;
        x[2][1] = 95;
        y[2][1] = 293;
        x[2][2] = 111;
        y[2][2] = 127;
        x[2][3] = 85;
        y[2][3] = 104;

        x[3][0] = 85;
        y[3][0] = 104;
        x[3][1] = 72;
        y[3][1] = 87;
        x[3][2] = 43;
        y[3][2] = 97;
        x[3][3] = 34;
        y[3][3] = 129;

        x[4][0] = 34;
        y[4][0] = 129;
        x[4][1] = 13;
        y[4][1] = 151;
        x[4][2] = 71;
        y[4][2] = 380;
        x[4][3] = 126;
        y[4][3] = 367;

        x[5][0] = 126;
        y[5][0] = 367;
        x[5][1] = 174;
        y[5][1] = 369;
        x[5][2] = 243;
        y[5][2] = 142;
        x[5][3] = 241;
        y[5][3] = 120;

        x[6][0] = 241;
        y[6][0] = 121;
        x[6][1] = 235;
        y[6][1] = 101;
        x[6][2] = 203;
        y[6][2] = 331;
        x[6][3] = 241;
        y[6][3] = 350;

        x[7][0] = 241;
        y[7][0] = 350;
        x[7][1] = 281;
        y[7][1] = 375;
        x[7][2] = 400;
        y[7][2] = 366;
        x[7][3] = 427;
        y[7][3] = 342;

        x[8][0] = 427;
        y[8][0] = 342;
        x[8][1] = 442;
        y[8][1] = 329;
        x[8][2] = 460;
        y[8][2] = 282;
        x[8][3] = 426;
        y[8][3] = 266;

        x[9][0] = 426;
        y[9][0] = 266;
        x[9][1] = 379;
        y[9][1] = 250;
        x[9][2] = 310;
        y[9][2] = 321;
        x[9][3] = 286;
        y[9][3] = 298;

        x[10][0] = 286;
        y[10][0] = 298;
        x[10][1] = 379;
        y[10][1] = 250;
        x[10][2] = 310;
        y[10][2] = 321;
        x[10][3] = 286;
        y[10][3] = 298;

        x[11][0] = 286;
        y[11][0] = 298;
        x[11][1] = 251;
        y[11][1] = 278;
        x[11][2] = 303;
        y[11][2] = 146;
        x[11][3] = 293;
        y[11][3] = 118;

        x[12][0] = 293;
        y[12][0] = 118;
        x[12][1] = 286;
        y[12][1] = 105;
        x[12][2] = 262;
        y[12][2] = 82;
        x[12][3] = 244;
        y[12][3] = 118;


    }

    private void drawBeziere(Graphics g)
    {
        Graphics2D g2d = (Graphics2D) g;
        g2d.setBackground(Color.white);
        g2d.fillRect(0, 0, 500, 500);
        g2d.setColor(Color.blue);

        for(int i = 0; i < 13; i++)
        {
            for(double t = 0.0; t <= 1.0; t+=0.003)
            {
                px = Math.pow(1-t, 3)*x[i][0] + 3*t*Math.pow(1-t, 2)*x[i][1] + 3*Math.pow(t, 2)*(1-t)*x[i][2] + Math.pow(t, 3) * x[i][3];
                py = Math.pow(1-t, 3)*y[i][0] + 3*t*Math.pow(1-t, 2)*y[i][1] + 3*Math.pow(t, 2)*(1-t)*y[i][2] + Math.pow(t, 3) * y[i][3];
                g2d.drawLine((int)px, (int)py, (int)px, (int)py);
            }
        }
    }
}

public class Main extends JFrame {

    private static final long serialVersionUID = 1L;
    public final int WIDTH = 500, HEIGHT = 500;

    public Main() {
        initUI();
    }

    private void initUI() {
        add(new Board());
        setSize(WIDTH, HEIGHT);
        setTitle("VL");
        setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }

    public static void main(String[] args) {
        EventQueue.invokeLater(() ->
        {Main ex = new Main();
            ex.setVisible(true);});
    }
}
